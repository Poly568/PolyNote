-- POLYNOTE : une ligne de données par utilisateur connecté.
create table if not exists public.polynote_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{"notes": [], "folders": []}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.polynote_data enable row level security;

-- Un utilisateur connecté ne peut lire que sa propre ligne.
create policy "Users can read their own POLYNOTE data"
on public.polynote_data for select to authenticated
using ((select auth.uid()) = user_id);

-- Un utilisateur connecté ne peut créer que sa propre ligne.
create policy "Users can insert their own POLYNOTE data"
on public.polynote_data for insert to authenticated
with check ((select auth.uid()) = user_id);

-- Un utilisateur connecté ne peut modifier que sa propre ligne.
create policy "Users can update their own POLYNOTE data"
on public.polynote_data for update to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

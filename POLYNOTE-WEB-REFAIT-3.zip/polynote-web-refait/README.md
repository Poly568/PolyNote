# POLYNOTE — version web

Adaptation web de POLYNOTE, avec notes structurées, dossiers, mise en forme, sauvegarde locale et synchronisation de notes par compte Supabase.

## Publier sur GitHub Pages ou Netlify

1. Ouvre `index.html` et remplace les deux valeurs de configuration `COLLER_ICI_URL_PROJET_SUPABASE` et `COLLER_ICI_CLE_PUBLIQUE_SUPABASE` par l'URL du projet Supabase et sa clé **publique** (anon/publishable).
2. Dans Supabase, ouvre **SQL Editor**, colle le contenu de `supabase.sql`, puis exécute-le.
3. Dans Supabase → **Authentication → URL Configuration**, configure l'URL du site et les URL de redirection de ton site publié.
4. Envoie ces fichiers dans un dépôt GitHub. Pour GitHub Pages, va dans **Settings → Pages** et publie depuis la branche principale, dossier `/ (root)`. Tu peux aussi déposer le dossier sur Netlify.

> Ne mets jamais une clé `service_role` ou une clé secrète dans `index.html` ou dans un dépôt public. Seule la clé publique Supabase est destinée à être utilisée côté navigateur; les règles RLS du fichier SQL limitent l'accès aux données de chaque utilisateur.

## Fonctionnement

- Sans configuration Supabase, les notes restent enregistrées localement dans le navigateur.
- Avec Supabase configuré et un compte connecté, les notes et dossiers sont synchronisés en ligne.
- La barre de mise en forme propose le réglage de taille façon POLYNOTE Swift : champ numérique en points, saisie de 6 à 96 pt et boutons `+` / `−` par incrément d'un point.

## À savoir

Cette version est une adaptation web en HTML/CSS/JavaScript, pas une compilation de l'application macOS Swift. Les interfaces natives macOS sont reproduites avec des contrôles web.
